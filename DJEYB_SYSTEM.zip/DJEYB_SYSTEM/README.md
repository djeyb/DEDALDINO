# ༆DJEYB༆ - Sistema de Edição de Vídeos, Fotos e Música com IA

Sistema completo e moderno para edição automática de vídeos, fotos e criação de música com inteligência artificial.

## Funcionalidades

### 🎬 Edição de Vídeos
- Efeitos exclusivos padrão
- Efeitos de legendas com voz
- Criação de novos efeitos via prompt
- Conteúdos cristãos

### 🎵 Sistema de Música
- IA canta no instrumental
- Seguir áudio exemplar
- Geração automática com IA
- Separação de voz e instrumental
- Busca de músicas na internet

### 📸 Edição de Fotos
- Melhoria de qualidade
- Colagem e fundos
- Criação automática de currículos
- Modelos personalizáveis via prompt

## Tecnologias

- Next.js 14
- TypeScript
- Tailwind CSS
- Prisma (Banco de dados)
- OpenAI API
- Replicate API

## Instalação

```bash
npm install
```

## Configuração

Crie um arquivo `.env` com:

```
DATABASE_URL="postgresql://user:password@localhost:5432/djeyb"
OPENAI_API_KEY="your-openai-key"
REPLICATE_API_TOKEN="your-replicate-token"
NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

## Executar

```bash
npm run dev
```


