'use client'

import { useState } from 'react'
import { Upload, Play, Download, Sparkles, Volume2, Type } from 'lucide-react'
import VideoEditor from '@/components/video/VideoEditor'
import EffectSelector from '@/components/video/EffectSelector'
import PromptEffectCreator from '@/components/video/PromptEffectCreator'
import SubtitleGenerator from '@/components/video/SubtitleGenerator'

export default function VideoPage() {
  const [activeTab, setActiveTab] = useState<'upload' | 'effects' | 'prompt' | 'subtitles'>('upload')
  const [videoFile, setVideoFile] = useState<File | null>(null)

  return (
    <div className="min-h-screen py-8">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gradient mb-4">
          Edição de Vídeos
        </h1>
        <p className="text-xl text-gray-300">
          Crie vídeos incríveis com efeitos exclusivos e IA
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 justify-center flex-wrap">
        <button
          onClick={() => setActiveTab('upload')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'upload'
              ? 'bg-purple-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          <Upload className="w-5 h-5 inline mr-2" />
          Carregar Vídeo
        </button>
        <button
          onClick={() => setActiveTab('effects')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'effects'
              ? 'bg-purple-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          <Sparkles className="w-5 h-5 inline mr-2" />
          Efeitos Padrão
        </button>
        <button
          onClick={() => setActiveTab('prompt')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'prompt'
              ? 'bg-purple-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          <Sparkles className="w-5 h-5 inline mr-2" />
          Criar Efeito (Prompt)
        </button>
        <button
          onClick={() => setActiveTab('subtitles')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'subtitles'
              ? 'bg-purple-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          <Type className="w-5 h-5 inline mr-2" />
          Legendas com Voz
        </button>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto">
        {activeTab === 'upload' && (
          <VideoEditor videoFile={videoFile} setVideoFile={setVideoFile} />
        )}
        {activeTab === 'effects' && (
          <EffectSelector videoFile={videoFile} />
        )}
        {activeTab === 'prompt' && (
          <PromptEffectCreator videoFile={videoFile} />
        )}
        {activeTab === 'subtitles' && (
          <SubtitleGenerator videoFile={videoFile} />
        )}
      </div>
    </div>
  )
}


