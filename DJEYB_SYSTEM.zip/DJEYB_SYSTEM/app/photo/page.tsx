'use client'

import { useState } from 'react'
import PhotoEditor from '@/components/photo/PhotoEditor'
import ResumeCreator from '@/components/photo/ResumeCreator'
import PhotoEnhancer from '@/components/photo/PhotoEnhancer'

export default function PhotoPage() {
  const [activeTab, setActiveTab] = useState<'editor' | 'resume' | 'enhancer'>('editor')

  return (
    <div className="min-h-screen py-8">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gradient mb-4">
          Edição de Fotos
        </h1>
        <p className="text-xl text-gray-300">
          Edite fotos, melhore qualidade e crie currículos profissionais
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 justify-center flex-wrap">
        <button
          onClick={() => setActiveTab('editor')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'editor'
              ? 'bg-pink-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          Editor de Fotos
        </button>
        <button
          onClick={() => setActiveTab('enhancer')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'enhancer'
              ? 'bg-pink-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          Melhorar Qualidade
        </button>
        <button
          onClick={() => setActiveTab('resume')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'resume'
              ? 'bg-pink-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          Criar Currículo
        </button>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto">
        {activeTab === 'editor' && <PhotoEditor />}
        {activeTab === 'enhancer' && <PhotoEnhancer />}
        {activeTab === 'resume' && <ResumeCreator />}
      </div>
    </div>
  )
}

