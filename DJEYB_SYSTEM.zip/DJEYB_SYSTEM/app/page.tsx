import Link from 'next/link'
import { Video, Music, Image as ImageIcon, Sparkles } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="text-center py-20">
        <div className="flex items-center justify-center mb-8">
          <h1 className="text-8xl font-bold text-gradient mb-4">
            ༆DJEYB༆
          </h1>
        </div>
        <p className="text-2xl text-gray-300 mb-12 max-w-3xl mx-auto">
          Sistema completo de edição de vídeos, fotos e criação de música com Inteligência Artificial
        </p>
        
        <div className="flex gap-6 justify-center mb-16">
          <Link 
            href="/video"
            className="glass-effect px-8 py-4 rounded-xl card-hover flex items-center gap-3 text-lg font-semibold"
          >
            <Video className="w-6 h-6" />
            Edição de Vídeos
          </Link>
          <Link 
            href="/music"
            className="glass-effect px-8 py-4 rounded-xl card-hover flex items-center gap-3 text-lg font-semibold"
          >
            <Music className="w-6 h-6" />
            Sistema de Música
          </Link>
          <Link 
            href="/photo"
            className="glass-effect px-8 py-4 rounded-xl card-hover flex items-center gap-3 text-lg font-semibold"
          >
            <ImageIcon className="w-6 h-6" />
            Edição de Fotos
          </Link>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid md:grid-cols-3 gap-8 mt-16">
        <div className="glass-effect p-8 rounded-2xl card-hover">
          <Video className="w-12 h-12 text-purple-400 mb-4" />
          <h3 className="text-2xl font-bold mb-4">Edição de Vídeos</h3>
          <p className="text-gray-300 mb-4">
            Efeitos exclusivos, legendas com voz, criação de efeitos via prompt e conteúdo cristão
          </p>
          <ul className="text-sm text-gray-400 space-y-2">
            <li>• Efeitos padrão exclusivos</li>
            <li>• Legendas com sua voz</li>
            <li>• Criação de efeitos via IA</li>
            <li>• Templates cristãos</li>
          </ul>
        </div>

        <div className="glass-effect p-8 rounded-2xl card-hover">
          <Music className="w-12 h-12 text-blue-400 mb-4" />
          <h3 className="text-2xl font-bold mb-4">Sistema de Música</h3>
          <p className="text-gray-300 mb-4">
            IA canta no instrumental, separação de voz, busca de músicas e muito mais
          </p>
          <ul className="text-sm text-gray-400 space-y-2">
            <li>• IA canta no instrumental</li>
            <li>• Separação voz/instrumental</li>
            <li>• Busca na internet</li>
            <li>• Geração automática</li>
          </ul>
        </div>

        <div className="glass-effect p-8 rounded-2xl card-hover">
          <ImageIcon className="w-12 h-12 text-pink-400 mb-4" />
          <h3 className="text-2xl font-bold mb-4">Edição de Fotos</h3>
          <p className="text-gray-300 mb-4">
            Melhoria de qualidade, colagens, fundos e criação automática de currículos
          </p>
          <ul className="text-sm text-gray-400 space-y-2">
            <li>• Melhoria de qualidade</li>
            <li>• Colagens e fundos</li>
            <li>• Currículos automáticos</li>
            <li>• Templates profissionais</li>
          </ul>
        </div>
      </div>

      {/* AI Badge */}
      <div className="text-center mt-16">
        <div className="inline-flex items-center gap-2 glass-effect px-6 py-3 rounded-full">
          <Sparkles className="w-5 h-5 text-yellow-400" />
          <span className="text-lg font-semibold">Powered by AI</span>
        </div>
      </div>
    </div>
  )
}


