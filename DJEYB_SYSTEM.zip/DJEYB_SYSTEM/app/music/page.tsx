'use client'

import { useState } from 'react'
import MusicGenerator from '@/components/music/MusicGenerator'
import VoiceSeparator from '@/components/music/VoiceSeparator'
import MusicSearch from '@/components/music/MusicSearch'
import AISinger from '@/components/music/AISinger'

export default function MusicPage() {
  const [activeTab, setActiveTab] = useState<'generate' | 'sing' | 'separate' | 'search'>('generate')

  return (
    <div className="min-h-screen py-8">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-gradient mb-4">
          Sistema de Música
        </h1>
        <p className="text-xl text-gray-300">
          Crie músicas com IA, separe vozes e muito mais
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-8 justify-center flex-wrap">
        <button
          onClick={() => setActiveTab('generate')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'generate'
              ? 'bg-blue-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          Gerar Música
        </button>
        <button
          onClick={() => setActiveTab('sing')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'sing'
              ? 'bg-blue-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          IA Canta
        </button>
        <button
          onClick={() => setActiveTab('separate')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'separate'
              ? 'bg-blue-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          Separar Voz/Instrumental
        </button>
        <button
          onClick={() => setActiveTab('search')}
          className={`px-6 py-3 rounded-lg font-semibold transition-all ${
            activeTab === 'search'
              ? 'bg-blue-500 text-white'
              : 'glass-effect text-gray-300 hover:text-white'
          }`}
        >
          Buscar Música
        </button>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto">
        {activeTab === 'generate' && <MusicGenerator />}
        {activeTab === 'sing' && <AISinger />}
        {activeTab === 'separate' && <VoiceSeparator />}
        {activeTab === 'search' && <MusicSearch />}
      </div>
    </div>
  )
}


