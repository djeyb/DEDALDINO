'use client'

import { useState } from 'react'
import { Music, Wand2, Loader2, Play, Download } from 'lucide-react'

export default function MusicGenerator() {
  const [mode, setMode] = useState<'auto' | 'lyrics' | 'prompt'>('auto')
  const [lyrics, setLyrics] = useState('')
  const [prompt, setPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedMusic, setGeneratedMusic] = useState<string | null>(null)

  const handleGenerate = async () => {
    setIsGenerating(true)
    try {
      // Simulação - aqui você integraria com a API de geração de música
      await new Promise(resolve => setTimeout(resolve, 3000))
      setGeneratedMusic('music-generated.mp3')
    } catch (error) {
      console.error(error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="glass-effect rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <Music className="w-8 h-8 text-blue-400" />
        <h2 className="text-3xl font-bold">Gerar Música com IA</h2>
      </div>

      <div className="space-y-6">
        {/* Mode Selection */}
        <div>
          <label className="block text-lg font-semibold mb-3">Modo de geração:</label>
          <div className="grid md:grid-cols-3 gap-4">
            <button
              onClick={() => setMode('auto')}
              className={`p-4 rounded-lg font-semibold transition-all ${
                mode === 'auto'
                  ? 'bg-blue-500 text-white'
                  : 'glass-effect text-gray-300 hover:text-white'
              }`}
            >
              Automático (IA decide)
            </button>
            <button
              onClick={() => setMode('lyrics')}
              className={`p-4 rounded-lg font-semibold transition-all ${
                mode === 'lyrics'
                  ? 'bg-blue-500 text-white'
                  : 'glass-effect text-gray-300 hover:text-white'
              }`}
            >
              Com Minha Letra
            </button>
            <button
              onClick={() => setMode('prompt')}
              className={`p-4 rounded-lg font-semibold transition-all ${
                mode === 'prompt'
                  ? 'bg-blue-500 text-white'
                  : 'glass-effect text-gray-300 hover:text-white'
              }`}
            >
              Com Prompt
            </button>
          </div>
        </div>

        {/* Content based on mode */}
        {mode === 'auto' && (
          <div className="p-6 bg-blue-500/20 border border-blue-500/50 rounded-lg">
            <p className="text-blue-200">
              A IA criará uma música completa automaticamente com letra e instrumental, 
              seguindo temas cristãos e estilo inspirador.
            </p>
          </div>
        )}

        {mode === 'lyrics' && (
          <div>
            <label className="block text-lg font-semibold mb-3">
              Digite sua letra:
            </label>
            <textarea
              value={lyrics}
              onChange={(e) => setLyrics(e.target.value)}
              placeholder="Digite a letra da música que você quer criar..."
              className="w-full h-48 bg-slate-800/50 border border-white/20 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>
        )}

        {mode === 'prompt' && (
          <div>
            <label className="block text-lg font-semibold mb-3">
              Descreva a música que deseja:
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ex: Uma música cristã de adoração, estilo gospel, com piano e violino, letra sobre gratidão..."
              className="w-full h-32 bg-slate-800/50 border border-white/20 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
            <p className="text-sm text-gray-400 mt-2">
              Seja específico sobre estilo, instrumentos, tema e emoção
            </p>
          </div>
        )}

        <button
          onClick={handleGenerate}
          disabled={isGenerating || (mode === 'lyrics' && !lyrics.trim()) || (mode === 'prompt' && !prompt.trim())}
          className="w-full glass-effect px-6 py-4 rounded-lg font-semibold hover:bg-blue-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Gerando música...
            </>
          ) : (
            <>
              <Wand2 className="w-5 h-5" />
              Gerar Música
            </>
          )}
        </button>

        {generatedMusic && (
          <div className="mt-6 p-6 bg-green-500/20 border border-green-500/50 rounded-lg">
            <p className="text-green-200 font-semibold mb-4">Música gerada com sucesso!</p>
            <div className="flex gap-4">
              <button className="flex-1 glass-effect px-4 py-2 rounded-lg hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
                <Play className="w-5 h-5" />
                Reproduzir
              </button>
              <button className="flex-1 glass-effect px-4 py-2 rounded-lg hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
                <Download className="w-5 h-5" />
                Baixar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}


