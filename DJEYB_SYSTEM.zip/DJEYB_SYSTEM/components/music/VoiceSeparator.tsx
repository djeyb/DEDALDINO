'use client'

import { useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Split, Upload, Download, Loader2 } from 'lucide-react'

export default function VoiceSeparator() {
  const [audioFile, setAudioFile] = useState<File | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [separatedFiles, setSeparatedFiles] = useState<{
    voice: string | null
    instrumental: string | null
  }>({ voice: null, instrumental: null })

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setAudioFile(acceptedFiles[0])
      }
    },
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a', '.ogg']
    },
    maxFiles: 1
  })

  const handleSeparate = async () => {
    if (!audioFile) return
    
    setIsProcessing(true)
    try {
      // Simulação - aqui você integraria com API de separação de áudio (como Spleeter)
      await new Promise(resolve => setTimeout(resolve, 5000))
      setSeparatedFiles({
        voice: 'voice-separated.mp3',
        instrumental: 'instrumental-separated.mp3'
      })
    } catch (error) {
      console.error(error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="glass-effect rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <Split className="w-8 h-8 text-blue-400" />
        <h2 className="text-3xl font-bold">Separar Voz e Instrumental</h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-lg font-semibold mb-3">
            Carregue a música completa:
          </label>
          {!audioFile ? (
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                isDragActive
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-gray-600 hover:border-blue-500 hover:bg-blue-500/5'
              }`}
            >
              <input {...getInputProps()} />
              <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p className="font-semibold mb-1">
                {isDragActive ? 'Solte o áudio aqui' : 'Arraste a música ou clique para selecionar'}
              </p>
              <p className="text-gray-400 text-sm">
                Formatos: MP3, WAV, M4A, OGG
              </p>
            </div>
          ) : (
            <div className="glass-effect p-4 rounded-lg flex items-center justify-between">
              <div>
                <p className="font-semibold">{audioFile.name}</p>
                <p className="text-sm text-gray-400">
                  {(audioFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
              <button
                onClick={() => {
                  setAudioFile(null)
                  setSeparatedFiles({ voice: null, instrumental: null })
                }}
                className="glass-effect p-2 rounded-lg hover:bg-red-500/20 transition-all"
              >
                Remover
              </button>
            </div>
          )}
        </div>

        <button
          onClick={handleSeparate}
          disabled={!audioFile || isProcessing}
          className="w-full glass-effect px-6 py-4 rounded-lg font-semibold hover:bg-blue-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Separando voz e instrumental...
            </>
          ) : (
            <>
              <Split className="w-5 h-5" />
              Separar Áudio
            </>
          )}
        </button>

        {separatedFiles.voice && separatedFiles.instrumental && (
          <div className="mt-6 space-y-4">
            <div className="p-6 bg-green-500/20 border border-green-500/50 rounded-lg">
              <p className="text-green-200 font-semibold mb-4">Separação concluída!</p>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="glass-effect p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Voz Separada</h3>
                  <p className="text-sm text-gray-400 mb-3">Apenas a voz da música</p>
                  <button className="w-full glass-effect px-4 py-2 rounded-lg hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
                    <Download className="w-4 h-4" />
                    Baixar Voz
                  </button>
                </div>
                
                <div className="glass-effect p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Instrumental Separado</h3>
                  <p className="text-sm text-gray-400 mb-3">Apenas o instrumental</p>
                  <button className="w-full glass-effect px-4 py-2 rounded-lg hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
                    <Download className="w-4 h-4" />
                    Baixar Instrumental
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

