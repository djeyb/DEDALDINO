'use client'

import { useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Mic, Upload, Play, Loader2, Download } from 'lucide-react'

export default function AISinger() {
  const [instrumentalFile, setInstrumentalFile] = useState<File | null>(null)
  const [referenceAudio, setReferenceAudio] = useState<File | null>(null)
  const [lyrics, setLyrics] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [generatedSong, setGeneratedSong] = useState<string | null>(null)

  const { getRootProps: getInstrumentalProps, getInputProps: getInstrumentalInputProps, isDragActive: isInstrumentalDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setInstrumentalFile(acceptedFiles[0])
      }
    },
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a', '.ogg']
    },
    maxFiles: 1
  })

  const { getRootProps: getReferenceProps, getInputProps: getReferenceInputProps, isDragActive: isReferenceDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setReferenceAudio(acceptedFiles[0])
      }
    },
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a', '.ogg']
    },
    maxFiles: 1
  })

  const handleGenerate = async () => {
    if (!instrumentalFile || !lyrics.trim()) return
    
    setIsProcessing(true)
    try {
      // Simulação - aqui você integraria com a API de síntese de voz/canto
      await new Promise(resolve => setTimeout(resolve, 4000))
      setGeneratedSong('song-generated.mp3')
    } catch (error) {
      console.error(error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="glass-effect rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <Mic className="w-8 h-8 text-blue-400" />
        <h2 className="text-3xl font-bold">IA Canta no Instrumental</h2>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-lg font-semibold mb-3">
            Carregue o instrumental:
          </label>
          {!instrumentalFile ? (
            <div
              {...getInstrumentalProps()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                isInstrumentalDragActive
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-gray-600 hover:border-blue-500 hover:bg-blue-500/5'
              }`}
            >
              <input {...getInstrumentalInputProps()} />
              <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p className="font-semibold mb-1">
                {isInstrumentalDragActive ? 'Solte o áudio aqui' : 'Arraste o instrumental ou clique para selecionar'}
              </p>
              <p className="text-gray-400 text-sm">
                Formatos: MP3, WAV, M4A, OGG
              </p>
            </div>
          ) : (
            <div className="glass-effect p-4 rounded-lg flex items-center justify-between">
              <div>
                <p className="font-semibold">{instrumentalFile.name}</p>
                <p className="text-sm text-gray-400">
                  {(instrumentalFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
              <button
                onClick={() => setInstrumentalFile(null)}
                className="glass-effect p-2 rounded-lg hover:bg-red-500/20 transition-all"
              >
                Remover
              </button>
            </div>
          )}
        </div>

        <div>
          <label className="block text-lg font-semibold mb-3">
            Digite a letra da música:
          </label>
          <textarea
            value={lyrics}
            onChange={(e) => setLyrics(e.target.value)}
            placeholder="Digite a letra que a IA irá cantar no instrumental..."
            className="w-full h-48 bg-slate-800/50 border border-white/20 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
          />
        </div>

        <div>
          <label className="block text-lg font-semibold mb-3">
            (Opcional) Carregue um áudio exemplar da voz:
          </label>
          {!referenceAudio ? (
            <div
              {...getReferenceProps()}
              className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
                isReferenceDragActive
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-gray-600 hover:border-blue-500 hover:bg-blue-500/5'
              }`}
            >
              <input {...getReferenceInputProps()} />
              <Upload className="w-10 h-10 mx-auto mb-2 text-gray-400" />
              <p className="text-sm font-semibold mb-1">
                {isReferenceDragActive ? 'Solte o áudio aqui' : 'Arraste um áudio exemplar'}
              </p>
              <p className="text-gray-400 text-xs">
                A IA usará este áudio como referência para o timbre e estilo
              </p>
            </div>
          ) : (
            <div className="glass-effect p-4 rounded-lg flex items-center justify-between">
              <div>
                <p className="font-semibold text-sm">{referenceAudio.name}</p>
                <p className="text-xs text-gray-400">
                  {(referenceAudio.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
              <button
                onClick={() => setReferenceAudio(null)}
                className="glass-effect p-2 rounded-lg hover:bg-red-500/20 transition-all"
              >
                Remover
              </button>
            </div>
          )}
          <p className="text-sm text-gray-400 mt-2">
            Se não carregar, a IA usará uma voz padrão cristã/gospel
          </p>
        </div>

        <button
          onClick={handleGenerate}
          disabled={!instrumentalFile || !lyrics.trim() || isProcessing}
          className="w-full glass-effect px-6 py-4 rounded-lg font-semibold hover:bg-blue-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Processando... A IA está cantando...
            </>
          ) : (
            <>
              <Mic className="w-5 h-5" />
              Fazer IA Cantar
            </>
          )}
        </button>

        {generatedSong && (
          <div className="mt-6 p-6 bg-green-500/20 border border-green-500/50 rounded-lg">
            <p className="text-green-200 font-semibold mb-4">Música gerada com sucesso!</p>
            <div className="flex gap-4">
              <button className="flex-1 glass-effect px-4 py-2 rounded-lg hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
                <Play className="w-5 h-5" />
                Reproduzir
              </button>
              <button className="flex-1 glass-effect px-4 py-2 rounded-lg hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
                <Download className="w-5 h-5" />
                Baixar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
