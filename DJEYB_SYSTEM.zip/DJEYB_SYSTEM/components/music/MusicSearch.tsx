'use client'

import { useState } from 'react'
import { Search, Download, Play, Loader2 } from 'lucide-react'

export default function MusicSearch() {
  const [searchQuery, setSearchQuery] = useState('')
  const [isSearching, setIsSearching] = useState(false)
  const [results, setResults] = useState<any[]>([])

  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    
    setIsSearching(true)
    try {
      // Simulação - aqui você integraria com API de busca de músicas
      await new Promise(resolve => setTimeout(resolve, 2000))
      setResults([
        { id: 1, title: 'Música Cristã 1', artist: 'Artista', duration: '3:45' },
        { id: 2, title: 'Música Cristã 2', artist: 'Artista', duration: '4:12' },
      ])
    } catch (error) {
      console.error(error)
    } finally {
      setIsSearching(false)
    }
  }

  return (
    <div className="glass-effect rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <Search className="w-8 h-8 text-blue-400" />
        <h2 className="text-3xl font-bold">Buscar Música na Internet</h2>
      </div>

      <div className="space-y-6">
        <div className="flex gap-4">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="Digite o nome da música, artista ou gênero..."
            className="flex-1 bg-slate-800/50 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={handleSearch}
            disabled={!searchQuery.trim() || isSearching}
            className="glass-effect px-6 py-3 rounded-lg font-semibold hover:bg-blue-500/20 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSearching ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Buscando...
              </>
            ) : (
              <>
                <Search className="w-5 h-5" />
                Buscar
              </>
            )}
          </button>
        </div>

        {results.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-lg font-semibold">Resultados:</h3>
            {results.map((result) => (
              <div
                key={result.id}
                className="glass-effect p-4 rounded-lg flex items-center justify-between"
              >
                <div>
                  <p className="font-semibold">{result.title}</p>
                  <p className="text-sm text-gray-400">{result.artist} • {result.duration}</p>
                </div>
                <div className="flex gap-2">
                  <button className="glass-effect p-2 rounded-lg hover:bg-blue-500/20 transition-all">
                    <Play className="w-5 h-5" />
                  </button>
                  <button className="glass-effect p-2 rounded-lg hover:bg-green-500/20 transition-all">
                    <Download className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {results.length === 0 && !isSearching && searchQuery && (
          <div className="text-center py-8 text-gray-400">
            <p>Nenhum resultado encontrado</p>
          </div>
        )}
      </div>
    </div>
  )
}

