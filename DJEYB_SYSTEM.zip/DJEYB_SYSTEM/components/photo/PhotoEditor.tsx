'use client'

import { useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, X, Download, Image as ImageIcon, Palette, Layers } from 'lucide-react'

export default function PhotoEditor() {
  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [photoUrl, setPhotoUrl] = useState<string | null>(null)
  const [selectedTool, setSelectedTool] = useState<'background' | 'collage' | 'filters'>('background')

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        const file = acceptedFiles[0]
        setPhotoFile(file)
        setPhotoUrl(URL.createObjectURL(file))
      }
    },
    accept: {
      'image/*': ['.jpg', '.jpeg', '.png', '.webp', '.gif']
    },
    maxFiles: 1
  })

  const removePhoto = () => {
    setPhotoFile(null)
    if (photoUrl) {
      URL.revokeObjectURL(photoUrl)
      setPhotoUrl(null)
    }
  }

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div className="glass-effect rounded-2xl p-8">
        <h2 className="text-2xl font-bold mb-6">Carregar Foto</h2>
        
        {!photoFile ? (
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-xl p-16 text-center cursor-pointer transition-all ${
              isDragActive
                ? 'border-pink-500 bg-pink-500/10'
                : 'border-gray-600 hover:border-pink-500 hover:bg-pink-500/5'
            }`}
          >
            <input {...getInputProps()} />
            <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <p className="text-xl font-semibold mb-2">
              {isDragActive ? 'Solte a foto aqui' : 'Arraste uma foto ou clique para selecionar'}
            </p>
            <p className="text-gray-400 text-sm">
              Formatos: JPG, PNG, WEBP, GIF
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="relative">
              {photoUrl && (
                <img
                  src={photoUrl}
                  alt="Preview"
                  className="w-full h-auto rounded-lg"
                />
              )}
              <button
                onClick={removePhoto}
                className="absolute top-2 right-2 glass-effect p-2 rounded-lg hover:bg-red-500/20 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="text-sm text-gray-400">
              <p>Nome: {photoFile.name}</p>
              <p>Tamanho: {(photoFile.size / (1024 * 1024)).toFixed(2)} MB</p>
            </div>
          </div>
        )}
      </div>

      <div className="glass-effect rounded-2xl p-8">
        <h2 className="text-2xl font-bold mb-6">Ferramentas de Edição</h2>
        
        <div className="space-y-4 mb-6">
          <button
            onClick={() => setSelectedTool('background')}
            className={`w-full p-4 rounded-lg font-semibold transition-all text-left flex items-center gap-3 ${
              selectedTool === 'background'
                ? 'bg-pink-500 text-white'
                : 'glass-effect text-gray-300 hover:text-white'
            }`}
          >
            <Palette className="w-5 h-5" />
            Trocar Fundo
          </button>
          <button
            onClick={() => setSelectedTool('collage')}
            className={`w-full p-4 rounded-lg font-semibold transition-all text-left flex items-center gap-3 ${
              selectedTool === 'collage'
                ? 'bg-pink-500 text-white'
                : 'glass-effect text-gray-300 hover:text-white'
            }`}
          >
            <Layers className="w-5 h-5" />
            Criar Colagem
          </button>
          <button
            onClick={() => setSelectedTool('filters')}
            className={`w-full p-4 rounded-lg font-semibold transition-all text-left flex items-center gap-3 ${
              selectedTool === 'filters'
                ? 'bg-pink-500 text-white'
                : 'glass-effect text-gray-300 hover:text-white'
            }`}
          >
            <ImageIcon className="w-5 h-5" />
            Filtros e Efeitos
          </button>
        </div>

        {selectedTool === 'background' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Trocar Fundo</h3>
            <input
              type="text"
              placeholder="Descreva o novo fundo (ex: praia ao pôr do sol, escritório moderno)..."
              className="w-full bg-slate-800/50 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-pink-500"
            />
            <button className="w-full glass-effect px-4 py-3 rounded-lg font-semibold hover:bg-pink-500/20 transition-all">
              Gerar Novo Fundo com IA
            </button>
          </div>
        )}

        {selectedTool === 'collage' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Criar Colagem</h3>
            <p className="text-sm text-gray-400">
              Selecione múltiplas fotos para criar uma colagem automática
            </p>
            <button className="w-full glass-effect px-4 py-3 rounded-lg font-semibold hover:bg-pink-500/20 transition-all">
              Adicionar Mais Fotos
            </button>
          </div>
        )}

        {selectedTool === 'filters' && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Filtros e Efeitos</h3>
            <div className="grid grid-cols-3 gap-2">
              {['Vintage', 'B&W', 'Warm', 'Cool', 'Bright', 'Dark'].map((filter) => (
                <button
                  key={filter}
                  className="glass-effect p-3 rounded-lg hover:bg-pink-500/20 transition-all text-sm"
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>
        )}

        {photoFile && (
          <button className="w-full mt-6 glass-effect px-6 py-3 rounded-lg font-semibold hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
            <Download className="w-5 h-5" />
            Baixar Foto Editada
          </button>
        )}
      </div>
    </div>
  )
}

