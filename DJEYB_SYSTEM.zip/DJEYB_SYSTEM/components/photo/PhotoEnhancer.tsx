'use client'

import { useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, X, Download, Sparkles, Loader2 } from 'lucide-react'

export default function PhotoEnhancer() {
  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [photoUrl, setPhotoUrl] = useState<string | null>(null)
  const [enhancementLevel, setEnhancementLevel] = useState('high')
  const [isProcessing, setIsProcessing] = useState(false)
  const [enhancedUrl, setEnhancedUrl] = useState<string | null>(null)

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        const file = acceptedFiles[0]
        setPhotoFile(file)
        setPhotoUrl(URL.createObjectURL(file))
      }
    },
    accept: {
      'image/*': ['.jpg', '.jpeg', '.png', '.webp']
    },
    maxFiles: 1
  })

  const handleEnhance = async () => {
    if (!photoFile) return
    
    setIsProcessing(true)
    try {
      // Simulação - aqui você integraria com API de melhoria de imagem
      await new Promise(resolve => setTimeout(resolve, 3000))
      setEnhancedUrl(photoUrl) // Em produção, seria a URL da imagem melhorada
    } catch (error) {
      console.error(error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="glass-effect rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <Sparkles className="w-8 h-8 text-pink-400" />
        <h2 className="text-3xl font-bold">Melhorar Qualidade da Foto</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div>
            <label className="block text-lg font-semibold mb-3">Carregue a foto:</label>
            {!photoFile ? (
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all ${
                  isDragActive
                    ? 'border-pink-500 bg-pink-500/10'
                    : 'border-gray-600 hover:border-pink-500 hover:bg-pink-500/5'
                }`}
              >
                <input {...getInputProps()} />
                <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="font-semibold mb-1">
                  {isDragActive ? 'Solte a foto aqui' : 'Arraste ou clique para selecionar'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="relative">
                  {photoUrl && (
                    <img
                      src={photoUrl}
                      alt="Original"
                      className="w-full h-auto rounded-lg"
                    />
                  )}
                  <button
                    onClick={() => {
                      setPhotoFile(null)
                      if (photoUrl) URL.revokeObjectURL(photoUrl)
                      setPhotoUrl(null)
                      setEnhancedUrl(null)
                    }}
                    className="absolute top-2 right-2 glass-effect p-2 rounded-lg hover:bg-red-500/20 transition-all"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <p className="text-sm text-gray-400">Original</p>
              </div>
            )}
          </div>

          <div>
            <label className="block text-lg font-semibold mb-3">Nível de melhoria:</label>
            <div className="space-y-2">
              {[
                { value: 'low', label: 'Baixo (melhoria rápida)' },
                { value: 'medium', label: 'Médio (equilíbrio)' },
                { value: 'high', label: 'Alto (máxima qualidade)' },
              ].map((option) => (
                <label
                  key={option.value}
                  className="flex items-center gap-3 glass-effect p-3 rounded-lg cursor-pointer hover:bg-pink-500/10 transition-all"
                >
                  <input
                    type="radio"
                    value={option.value}
                    checked={enhancementLevel === option.value}
                    onChange={(e) => setEnhancementLevel(e.target.value)}
                    className="w-4 h-4 text-pink-500"
                  />
                  <span>{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <button
            onClick={handleEnhance}
            disabled={!photoFile || isProcessing}
            className="w-full glass-effect px-6 py-4 rounded-lg font-semibold hover:bg-pink-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Melhorando qualidade...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Melhorar Foto
              </>
            )}
          </button>
        </div>

        <div>
          {enhancedUrl && (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={enhancedUrl}
                  alt="Melhorada"
                  className="w-full h-auto rounded-lg"
                />
              </div>
              <p className="text-sm text-gray-400">Melhorada</p>
              <button className="w-full glass-effect px-6 py-3 rounded-lg font-semibold hover:bg-green-500/20 transition-all flex items-center justify-center gap-2">
                <Download className="w-5 h-5" />
                Baixar Foto Melhorada
              </button>
            </div>
          )}
          {!enhancedUrl && photoFile && (
            <div className="h-full flex items-center justify-center text-gray-400">
              <p>A foto melhorada aparecerá aqui</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

