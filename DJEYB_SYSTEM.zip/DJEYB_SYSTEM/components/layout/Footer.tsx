export default function Footer() {
  return (
    <footer className="glass-effect border-t border-white/10 mt-20">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-gray-400 mb-2">
            © 2024 <span className="text-gradient font-bold">༆DJEYB༆</span> - Todos os direitos reservados
          </p>
          <p className="text-sm text-gray-500">
            Sistema de edição com Inteligência Artificial
          </p>
        </div>
      </div>
    </footer>
  )
}


