'use client'

import { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, X, Play, Download } from 'lucide-react'
import ReactPlayer from 'react-player'

interface VideoEditorProps {
  videoFile: File | null
  setVideoFile: (file: File | null) => void
}

export default function VideoEditor({ videoFile, setVideoFile }: VideoEditorProps) {
  const [videoUrl, setVideoUrl] = useState<string | null>(null)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0]
      setVideoFile(file)
      setVideoUrl(URL.createObjectURL(file))
    }
  }, [setVideoFile])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi', '.mkv', '.webm']
    },
    maxFiles: 1
  })

  const removeVideo = () => {
    setVideoFile(null)
    if (videoUrl) {
      URL.revokeObjectURL(videoUrl)
      setVideoUrl(null)
    }
  }

  return (
    <div className="glass-effect rounded-2xl p-8">
      {!videoFile ? (
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-xl p-16 text-center cursor-pointer transition-all ${
            isDragActive
              ? 'border-purple-500 bg-purple-500/10'
              : 'border-gray-600 hover:border-purple-500 hover:bg-purple-500/5'
          }`}
        >
          <input {...getInputProps()} />
          <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
          <p className="text-xl font-semibold mb-2">
            {isDragActive ? 'Solte o vídeo aqui' : 'Arraste um vídeo ou clique para selecionar'}
          </p>
          <p className="text-gray-400 text-sm">
            Formatos suportados: MP4, MOV, AVI, MKV, WEBM
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-2">{videoFile.name}</h3>
              <p className="text-gray-400">
                {(videoFile.size / (1024 * 1024)).toFixed(2)} MB
              </p>
            </div>
            <button
              onClick={removeVideo}
              className="glass-effect p-3 rounded-lg hover:bg-red-500/20 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="bg-black rounded-xl overflow-hidden">
            {videoUrl && (
              <ReactPlayer
                url={videoUrl}
                controls
                width="100%"
                height="auto"
                playing={false}
              />
            )}
          </div>

          <div className="flex gap-4">
            <button className="flex-1 glass-effect px-6 py-3 rounded-lg font-semibold hover:bg-purple-500/20 transition-all flex items-center justify-center gap-2">
              <Play className="w-5 h-5" />
              Processar Vídeo
            </button>
            <button className="flex-1 glass-effect px-6 py-3 rounded-lg font-semibold hover:bg-blue-500/20 transition-all flex items-center justify-center gap-2">
              <Download className="w-5 h-5" />
              Baixar Resultado
            </button>
          </div>
        </div>
      )}
    </div>
  )
}


