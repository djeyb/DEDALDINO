'use client'

import { useState } from 'react'
import { Sparkles, Wand2, Loader2 } from 'lucide-react'

interface PromptEffectCreatorProps {
  videoFile: File | null
}

export default function PromptEffectCreator({ videoFile }: PromptEffectCreatorProps) {
  const [prompt, setPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedEffect, setGeneratedEffect] = useState<string | null>(null)

  const handleGenerate = async () => {
    if (!prompt.trim()) return
    
    setIsGenerating(true)
    try {
      // Simulação - aqui você integraria com a API de IA
      await new Promise(resolve => setTimeout(resolve, 2000))
      setGeneratedEffect('Efeito gerado com sucesso!')
    } catch (error) {
      console.error(error)
    } finally {
      setIsGenerating(false)
    }
  }

  const examples = [
    'Crie um efeito de partículas douradas caindo do céu',
    'Adicione raios de luz divina saindo do centro',
    'Efeito de transição com cruz brilhante',
    'Partículas de fogo santo flutuando',
    'Overlay de texto bíblico com animação',
  ]

  return (
    <div className="glass-effect rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <Wand2 className="w-8 h-8 text-purple-400" />
        <h2 className="text-3xl font-bold">Criar Efeito com IA</h2>
      </div>

      {!videoFile && (
        <div className="mb-6 p-4 bg-yellow-500/20 border border-yellow-500/50 rounded-lg">
          <p className="text-yellow-200">
            Carregue um vídeo primeiro na aba "Carregar Vídeo"
          </p>
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-lg font-semibold mb-3">
            Descreva o efeito que deseja criar:
          </label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ex: Crie um efeito de partículas douradas caindo do céu com uma cruz brilhante no centro..."
            className="w-full h-32 bg-slate-800/50 border border-white/20 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
          />
          <p className="text-sm text-gray-400 mt-2">
            Seja específico sobre cores, movimento, intensidade e tema cristão
          </p>
        </div>

        <div>
          <p className="text-lg font-semibold mb-3">Exemplos de prompts:</p>
          <div className="grid md:grid-cols-2 gap-3">
            {examples.map((example, idx) => (
              <button
                key={idx}
                onClick={() => setPrompt(example)}
                className="text-left glass-effect p-4 rounded-lg hover:bg-purple-500/20 transition-all text-sm"
              >
                {example}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={!prompt.trim() || isGenerating}
          className="w-full glass-effect px-6 py-4 rounded-lg font-semibold hover:bg-purple-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Gerando efeito...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              Gerar Efeito com IA
            </>
          )}
        </button>

        {generatedEffect && (
          <div className="mt-6 p-6 bg-green-500/20 border border-green-500/50 rounded-lg">
            <p className="text-green-200 font-semibold mb-2">Efeito gerado!</p>
            <p className="text-gray-300">{generatedEffect}</p>
            <button className="mt-4 glass-effect px-4 py-2 rounded-lg hover:bg-green-500/20 transition-all">
              Aplicar ao Vídeo
            </button>
          </div>
        )}
      </div>
    </div>
  )
}


