'use client'

import { useState } from 'react'
import { Sparkles, Play, Check } from 'lucide-react'

interface EffectSelectorProps {
  videoFile: File | null
}

const effects = [
  {
    id: 'glow',
    name: 'Efeito Glow',
    description: 'Adiciona brilho e luminosidade ao vídeo',
    category: 'Visual',
    preview: '✨'
  },
  {
    id: 'particles',
    name: 'Partículas Divinas',
    description: 'Partículas flutuantes com tema cristão',
    category: 'Cristão',
    preview: '🌟'
  },
  {
    id: 'light-rays',
    name: 'Raios de Luz',
    description: 'Raios de luz celestial',
    category: 'Cristão',
    preview: '☀️'
  },
  {
    id: 'cross-overlay',
    name: 'Overlay de Cruz',
    description: 'Sobreposição elegante de cruz',
    category: 'Cristão',
    preview: '✝️'
  },
  {
    id: 'blur-transition',
    name: 'Transição Blur',
    description: 'Transições suaves com desfoque',
    category: 'Transição',
    preview: '🌀'
  },
  {
    id: 'zoom-pan',
    name: 'Zoom e Pan',
    description: 'Movimentos dinâmicos de câmera',
    category: 'Movimento',
    preview: '🔍'
  },
]

export default function EffectSelector({ videoFile }: EffectSelectorProps) {
  const [selectedEffects, setSelectedEffects] = useState<string[]>([])

  const toggleEffect = (effectId: string) => {
    setSelectedEffects(prev =>
      prev.includes(effectId)
        ? prev.filter(id => id !== effectId)
        : [...prev, effectId]
    )
  }

  const categories = Array.from(new Set(effects.map(e => e.category)))

  return (
    <div className="space-y-6">
      {!videoFile && (
        <div className="glass-effect rounded-xl p-6 text-center">
          <p className="text-gray-400">
            Carregue um vídeo primeiro na aba "Carregar Vídeo"
          </p>
        </div>
      )}

      <div className="glass-effect rounded-2xl p-8">
        <h2 className="text-3xl font-bold mb-6">Efeitos Exclusivos Padrão</h2>
        
        {categories.map(category => (
          <div key={category} className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-purple-300">{category}</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {effects
                .filter(e => e.category === category)
                .map(effect => (
                  <div
                    key={effect.id}
                    onClick={() => toggleEffect(effect.id)}
                    className={`glass-effect p-6 rounded-xl cursor-pointer transition-all card-hover ${
                      selectedEffects.includes(effect.id)
                        ? 'ring-2 ring-purple-500 bg-purple-500/20'
                        : ''
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <span className="text-3xl">{effect.preview}</span>
                      {selectedEffects.includes(effect.id) && (
                        <Check className="w-5 h-5 text-purple-400" />
                      )}
                    </div>
                    <h4 className="text-lg font-bold mb-2">{effect.name}</h4>
                    <p className="text-sm text-gray-400">{effect.description}</p>
                  </div>
                ))}
            </div>
          </div>
        ))}

        {selectedEffects.length > 0 && (
          <div className="mt-8 pt-6 border-t border-white/10">
            <div className="flex items-center justify-between">
              <p className="text-lg">
                <span className="font-semibold">{selectedEffects.length}</span> efeito(s) selecionado(s)
              </p>
              <button className="glass-effect px-6 py-3 rounded-lg font-semibold hover:bg-purple-500/20 transition-all flex items-center gap-2">
                <Play className="w-5 h-5" />
                Aplicar Efeitos
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}


