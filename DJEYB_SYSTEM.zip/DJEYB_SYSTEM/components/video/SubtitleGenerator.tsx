'use client'

import { useState } from 'react'
import { Type, Volume2, Upload, Loader2 } from 'lucide-react'
import { useDropzone } from 'react-dropzone'

interface SubtitleGeneratorProps {
  videoFile: File | null
}

export default function SubtitleGenerator({ videoFile }: SubtitleGeneratorProps) {
  const [subtitles, setSubtitles] = useState('')
  const [voiceFile, setVoiceFile] = useState<File | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        setVoiceFile(acceptedFiles[0])
      }
    },
    accept: {
      'audio/*': ['.mp3', '.wav', '.m4a', '.ogg']
    },
    maxFiles: 1
  })

  const handleGenerate = async () => {
    if (!subtitles.trim() || !voiceFile) return
    
    setIsProcessing(true)
    try {
      // Simulação - aqui você integraria com a API de síntese de voz
      await new Promise(resolve => setTimeout(resolve, 3000))
      alert('Legendas com voz geradas com sucesso!')
    } catch (error) {
      console.error(error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="glass-effect rounded-2xl p-8">
      <div className="flex items-center gap-3 mb-6">
        <Type className="w-8 h-8 text-purple-400" />
        <h2 className="text-3xl font-bold">Legendas com Sua Voz</h2>
      </div>

      {!videoFile && (
        <div className="mb-6 p-4 bg-yellow-500/20 border border-yellow-500/50 rounded-lg">
          <p className="text-yellow-200">
            Carregue um vídeo primeiro na aba "Carregar Vídeo"
          </p>
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-lg font-semibold mb-3">
            Digite o texto das legendas:
          </label>
          <textarea
            value={subtitles}
            onChange={(e) => setSubtitles(e.target.value)}
            placeholder="Digite o texto que será narrado nas legendas..."
            className="w-full h-40 bg-slate-800/50 border border-white/20 rounded-lg p-4 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
          />
        </div>

        <div>
          <label className="block text-lg font-semibold mb-3">
            Carregue um áudio exemplar da sua voz:
          </label>
          {!voiceFile ? (
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                isDragActive
                  ? 'border-purple-500 bg-purple-500/10'
                  : 'border-gray-600 hover:border-purple-500 hover:bg-purple-500/5'
              }`}
            >
              <input {...getInputProps()} />
              <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
              <p className="font-semibold mb-1">
                {isDragActive ? 'Solte o áudio aqui' : 'Arraste um áudio ou clique para selecionar'}
              </p>
              <p className="text-gray-400 text-sm">
                Formatos: MP3, WAV, M4A, OGG
              </p>
            </div>
          ) : (
            <div className="glass-effect p-4 rounded-lg flex items-center justify-between">
              <div>
                <p className="font-semibold">{voiceFile.name}</p>
                <p className="text-sm text-gray-400">
                  {(voiceFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
              <button
                onClick={() => setVoiceFile(null)}
                className="glass-effect p-2 rounded-lg hover:bg-red-500/20 transition-all"
              >
                Remover
              </button>
            </div>
          )}
          <p className="text-sm text-gray-400 mt-2">
            A IA usará este áudio como referência para gerar a narração das legendas
          </p>
        </div>

        <div className="flex gap-4">
          <button
            onClick={handleGenerate}
            disabled={!subtitles.trim() || !voiceFile || isProcessing}
            className="flex-1 glass-effect px-6 py-4 rounded-lg font-semibold hover:bg-purple-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <Volume2 className="w-5 h-5" />
                Gerar Legendas com Voz
              </>
            )}
          </button>
        </div>

        <div className="p-4 bg-blue-500/20 border border-blue-500/50 rounded-lg">
          <p className="text-blue-200 text-sm">
            💡 <strong>Dica:</strong> Use um áudio claro da sua voz falando por alguns segundos. 
            A IA aprenderá seu timbre e estilo para gerar as legendas.
          </p>
        </div>
      </div>
    </div>
  )
}


